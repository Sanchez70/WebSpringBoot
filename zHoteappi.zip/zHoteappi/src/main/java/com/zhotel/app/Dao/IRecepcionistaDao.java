package com.zhotel.app.Dao;

import org.springframework.data.repository.CrudRepository;

import com.zhotel.app.Entity.*;

public interface IRecepcionistaDao extends CrudRepository<Recepcionista,Long>{

}
