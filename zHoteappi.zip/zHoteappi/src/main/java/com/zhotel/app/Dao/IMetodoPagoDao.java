package com.zhotel.app.Dao;

import org.springframework.data.repository.CrudRepository;

import com.zhotel.app.Entity.*;

public interface IMetodoPagoDao extends CrudRepository<MetodoPago,Long>{

}
